Welcome to SoundLens!

For a more detailed overview of what SoundLens is and what it does, check out my Devpost https://devpost.com/software/soundlens-dcsfhx

The latest version of Processing is required to run this project, and can be downloaded here:
https://processing.org/

Simply open the project folder in Processing and click “run”

To add new songs, drag the .mp3 file into the “Data” folder.
Then, change the value of String FILE_NAME to the file’s name (case sensitive, include extension).

All songs included in the Data folder are my own, so I have permission to share these files.

This project was built in Processing 3.0 using the Minim library.

Enjoy!
Jonny
